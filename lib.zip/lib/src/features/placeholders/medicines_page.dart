import 'package:flutter/material.dart';

class MedicinesPage extends StatelessWidget {
  const MedicinesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Medicines'));
  }
}


