import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:permission_handler/permission_handler.dart';
import 'dart:io' show Platform;
import 'tts_service.dart';

class NotificationService {
  // Singleton
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _notificationsPlugin =
  FlutterLocalNotificationsPlugin();

  // TTS injected from main.dart (for foreground use)
  late TtsService ttsService;

  void registerTtsService(TtsService service) {
    ttsService = service;
  }

  // ===========================================================================
  // INITIALIZE
  // ===========================================================================
  Future<void> initialize() async {
    tz.setLocalLocation(tz.getLocation('Asia/Kolkata'));

    const AndroidInitializationSettings androidSettings =
    AndroidInitializationSettings('@mipmap/ic_launcher');
    const DarwinInitializationSettings iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notificationsPlugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (response) async {
        print('NOTIFICATION TAPPED: ${response.payload}');
        if (Platform.isAndroid) {
          await _handleAndroidTTS(response.payload);
        }
      },
      onDidReceiveBackgroundNotificationResponse: _androidBackgroundNotificationHandler,
    );

    // Android 13+ Permissions & Channels
    if (Platform.isAndroid) {
      final androidPlugin = _notificationsPlugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

      final status = await Permission.notification.status;
      if (status.isDenied) {
        await androidPlugin?.requestNotificationsPermission();
      }

      await androidPlugin?.requestExactAlarmsPermission();
      final canExact = await androidPlugin?.canScheduleExactNotifications() ?? false;
      if (!canExact) {
        print('WARNING: Exact alarms disabled. Guide user to enable in Settings.');
      }

      // MEDICINE CHANNEL – uses custom sound that says "Time to take medicine"
      await androidPlugin?.createNotificationChannel(
        const AndroidNotificationChannel(
          'medicine_reminder_channel',
          'Medicine Reminders',
          description: 'Notifications for taking medicines on time',
          importance: Importance.max,
          playSound: true,
          sound: RawResourceAndroidNotificationSound('tts_sound'), // ← CUSTOM SOUND
          enableVibration: true,
        ),
      );

      await androidPlugin?.createNotificationChannel(
        const AndroidNotificationChannel(
          'appointment_reminder_channel',
          'Appointment Reminders',
          description: 'Reminders for doctor appointments',
          importance: Importance.max,
          playSound: true,
        ),
      );

      await androidPlugin?.createNotificationChannel(
        const AndroidNotificationChannel(
          'daily_summary_channel',
          'Daily Summary',
          description: 'Daily health summary notifications',
          importance: Importance.high,
        ),
      );
    }

    // iOS fallback
    if (await Permission.notification.isDenied) {
      await Permission.notification.request();
    }
  }

  // ===========================================================================
  // BACKGROUND HANDLER – Works when app is background/terminated
  // ===========================================================================
  @pragma('vm:entry-point')
  static void _androidBackgroundNotificationHandler(NotificationResponse response) async {
    if (!Platform.isAndroid) return;

    final tts = TtsService();
    try {
      await tts.initialize();
      if (response.payload?.startsWith('medicine_') == true) {
        await tts.speak("Time to take medicine");
      } else if (response.payload == 'instant_test') {
        await tts.speak("Test notification triggered.");
      }
    } catch (e) {
      print("Background TTS failed: $e");
    } finally {
      await tts.stop();
    }
  }

  // Foreground/Tap TTS
  Future<void> _handleAndroidTTS(String? payload) async {
    if (!Platform.isAndroid || payload == null) return;

    try {
      if (payload.startsWith('medicine_')) {
        await ttsService.speak("Time to take medicine");
      } else if (payload == 'instant_test') {
        await ttsService.speak("Test notification triggered.");
      }
    } catch (e) {
      print("Foreground TTS failed: $e");
    }
  }

  // ===========================================================================
  // INSTANT NOTIFICATION
  // ===========================================================================
  Future<void> showInstantNotification({
    required String title,
    required String body,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'medicine_reminder_channel',
      'Medicine Reminders',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      fullScreenIntent: true,
      sound: RawResourceAndroidNotificationSound('tts_sound'),
    );
    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );
    const details = NotificationDetails(android: androidDetails, iOS: iosDetails);

    await _notificationsPlugin.show(
      999999,
      title,
      body,
      details,
      payload: 'instant_test',
    );
  }

  // ===========================================================================
  // MEDICINE REMINDER (Daily repeating)
  // ===========================================================================
  Future<void> scheduleMedicineReminder({
    required String medicineId,
    required String medicineName,
    required String dosage,
    required List<String> timesOfDay,
    required DateTime startDate,
  }) async {
    final now = DateTime.now();
    if (now.isBefore(startDate)) {
      print('Medicine $medicineName starts in future. Skipping.');
      return;
    }

    final canExact = await checkExactAlarmsPermission();
    final scheduleMode = canExact
        ? AndroidScheduleMode.exactAllowWhileIdle
        : AndroidScheduleMode.inexactAllowWhileIdle;

    const androidDetails = AndroidNotificationDetails(
      'medicine_reminder_channel',
      'Medicine Reminders',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      fullScreenIntent: true,
      sound: RawResourceAndroidNotificationSound('tts_sound'), // ← Plays "Time to take medicine"
      visibility: NotificationVisibility.public,
      ticker: 'Take your medicine!',
    );
    const iosDetails = DarwinNotificationDetails(presentAlert: true, presentBadge: true, presentSound: true);
    const notifDetails = NotificationDetails(android: androidDetails, iOS: iosDetails);

    for (String timeStr in timesOfDay) {
      final parts = timeStr.split(':');
      if (parts.length != 2) continue;
      final hour = int.tryParse(parts[0]) ?? 0;
      final minute = int.tryParse(parts[1]) ?? 0;

      var target = DateTime(now.year, now.month, now.day, hour, minute);
      if (target.isBefore(now)) target = target.add(const Duration(days: 1));

      final scheduledTime = tz.TZDateTime.from(target, tz.local);
      final notificationId = (medicineId.hashCode + timeStr.hashCode).abs();

      final pending = await _notificationsPlugin.pendingNotificationRequests();
      if (pending.any((n) => n.id == notificationId)) {
        print("Already scheduled: $medicineName @ $timeStr");
        continue;
      }

      await _notificationsPlugin.zonedSchedule(
        notificationId,
        'Time for your medicine!',
        '$medicineName - $dosage',
        scheduledTime,
        notifDetails,
        androidScheduleMode: scheduleMode,
        matchDateTimeComponents: DateTimeComponents.time,
        payload: 'medicine_$medicineId',
      );
    }
  }

  // ===========================================================================
  // Other methods (appointment, daily summary, helpers, cancel, debug) remain unchanged
  // ===========================================================================
  Future<void> scheduleAppointmentReminder({
    required int id,
    required String doctorName,
    required String hospital,
    required DateTime appointmentTime,
  }) async {
    final reminderTime = appointmentTime.subtract(const Duration(hours: 1));
    final tzTime = _toFutureTzDateTime(reminderTime);
    final canExact = await checkExactAlarmsPermission();
    final scheduleMode = canExact ? AndroidScheduleMode.exactAllowWhileIdle : AndroidScheduleMode.inexactAllowWhileIdle;

    const androidDetails = AndroidNotificationDetails(
      'appointment_reminder_channel',
      'Appointment Reminders',
      importance: Importance.max,
      priority: Priority.high,
      fullScreenIntent: true,
      playSound: true,
    );
    const iosDetails = DarwinNotificationDetails(presentAlert: true, presentBadge: true, presentSound: true);
    final details = NotificationDetails(android: androidDetails, iOS: iosDetails);

    await _notificationsPlugin.zonedSchedule(
      id,
      'Upcoming Appointment',
      'Dr. $doctorName at $hospital in 1 hour',
      tzTime,
      details,
      androidScheduleMode: scheduleMode,
      payload: 'appointment_$id',
    );
  }

  Future<void> scheduleDailySummary({required int hour, required int minute}) async {
    final canExact = await checkExactAlarmsPermission();
    final scheduleMode = canExact ? AndroidScheduleMode.exactAllowWhileIdle : AndroidScheduleMode.inexactAllowWhileIdle;

    const androidDetails = AndroidNotificationDetails('dailysummary_channel', 'Daily Summary', importance: Importance.high);
    const iosDetails = DarwinNotificationDetails(presentAlert: true, presentBadge: true, presentSound: true);
    final details = NotificationDetails(android: androidDetails, iOS: iosDetails);

    await _notificationsPlugin.zonedSchedule(
      999,
      'Daily Health Summary',
      'Check your pending medicines and appointments',
      _nextInstanceOfTime(hour, minute),
      details,
      androidScheduleMode: scheduleMode,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  tz.TZDateTime _toFutureTzDateTime(DateTime dateTime) {
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime.from(dateTime, tz.local);
    if (scheduled.isBefore(now)) scheduled = scheduled.add(const Duration(days: 1));
    return scheduled;
  }

  tz.TZDateTime _nextInstanceOfTime(int hour, int minute) {
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (scheduled.isBefore(now)) scheduled = scheduled.add(const Duration(days: 1));
    return scheduled;
  }

  Future<void> cancelNotification(int id) async => await _notificationsPlugin.cancel(id);
  Future<void> cancelAllNotifications() async => await _notificationsPlugin.cancelAll();
  Future<List<PendingNotificationRequest>> getPendingNotifications() async =>
      await _notificationsPlugin.pendingNotificationRequests();

  Future<void> debugScheduleIn10Seconds() async {
    final canExact = await checkExactAlarmsPermission();
    final scheduleMode = canExact ? AndroidScheduleMode.exactAllowWhileIdle : AndroidScheduleMode.inexactAllowWhileIdle;
    final time = tz.TZDateTime.now(tz.local).add(const Duration(seconds: 10));

    await _notificationsPlugin.zonedSchedule(
      888888,
      'DEBUG TEST',
      'This should appear in 10 seconds',
      time,
      const NotificationDetails(
        android: AndroidNotificationDetails('medicine_reminder_channel', 'Test', sound: RawResourceAndroidNotificationSound('tts_sound')),
        iOS: DarwinNotificationDetails(presentAlert: true, presentBadge: true, presentSound: true),
      ),
      androidScheduleMode: scheduleMode,
      payload: 'instant_test',
    );
  }

  Future<bool> checkExactAlarmsPermission() async {
    if (!Platform.isAndroid) return true;

    final androidPlugin = _notificationsPlugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();

    // This directly requests the "Alarms & reminders" permission (Android 13+)
    await androidPlugin?.requestExactAlarmsPermission();

    final canExact = await androidPlugin?.canScheduleExactNotifications() ?? false;
    if (!canExact) {
      print('Exact alarms permission denied. Reminders may be delayed by Android.');
    }
    return canExact;
  }
}